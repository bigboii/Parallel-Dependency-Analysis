namespace NS2
{
	class X
	{
	public:
		void xFunct();
	}	
}