#include "X.h"
#include "X2.h"
using namespace NS1;

int main()
{
	X x;
	NS2::X x2;
}

