using namespace ULTRA;

namespace Namepace1
{
	using token = std::string;	
	class TestClass
	{
		
	}

	struct TestStruct 
	{
		
	}

	enum TestEnum
	{
		typedef std::string token3;
		using token2 = std::string;	
	}
}