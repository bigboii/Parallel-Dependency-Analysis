class Y
{
public:
		void yFunct();

private:
	X x;
	TestEnum testEnum;
}