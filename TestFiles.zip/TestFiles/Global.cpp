#include "Global.h"
#include "Global2.h"

int globalFunct()
{
	std::cout << "I'm a global function" <<std::endl;
}

int globalFunct2()
{
	std::cout << "I'm another global function" << std::endl;
}