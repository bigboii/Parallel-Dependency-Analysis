#include "X.h"
#include "Namespace1.h"
#include "Global.h"

int main()
{
	Y y;
	y.yFunct();
	globalFunct();
}