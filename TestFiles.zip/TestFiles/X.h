namespace NS1
{
	class X
	{
	public:
		void xFunct();
	}	
}